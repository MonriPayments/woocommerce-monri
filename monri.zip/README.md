# woocommerce-monri
WooCommerce Plugin

Installation guide:
- go to releases page https://github.com/MonriPayments/woocommerce-plugin/releases
- click on latest release
- download 'woocommerce-monri.zip'
- use [installation guide](https://github.com/MonriPayments/woocommerce-plugin/raw/master/Monri_woocommerce_postavke.pdf) to complete installation
