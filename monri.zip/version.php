<?php

    echo "<span>Plugin Name: Woocommerce Monri plugin</span></br>";
    echo "<span>Plugin URI: http://www.monri.com</span></br>";
    echo "<span>Description: Monri - Payment gateway for woocommerce</span></br>";
    echo "<span>Version: 2.11</span></br>";
    echo "<span>Author: Monri Payments d.o.o</span></br>";
    echo "<span>Author URI: http://www.monri.com</span></br>";

?>



